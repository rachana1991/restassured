package LibraryAPI;

import static io.restassured.RestAssured.given;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import files.payload;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.path.xml.XmlPath;
import io.restassured.response.Response;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;

public class AddDeleteBook {

	@Test(dataProvider="getData")
	public void addbook(String isbn, String aisle) {
	RestAssured.baseURI ="http://216.10.245.166";
	Response res = given().	
	body(payload.addBook(isbn,aisle)).log().all().
	when().
	post("/Library/Addbook.php").
	then().assertThat().statusCode(200).and().contentType(ContentType.JSON).log().all().
	extract().response();
	
	  String responseString =res.asString();
	  JsonPath js = new JsonPath(responseString);
			String bookId= js.get("ID");
			System.out.println(bookId);
}
	
	
	
	@Test(dataProvider="getData")
	public void deleteBook(String isbn, String aisle) {
		
		RestAssured.baseURI ="http://216.10.245.166";
		Response res = given().	
		body("{\r\n" + 
				" \r\n" + 
				"\"ID\" : \""+isbn+aisle+"\"\r\n" + 
				" \r\n" + 
				"} \r\n" + 
				"").
		when().
		post("/Library/DeleteBook.php").
		then().assertThat().statusCode(200).and().contentType(ContentType.JSON).log().all().
		extract().response();
	}
	
	
	@DataProvider(name="getData")
	public Object[][] booksData() {
		return new Object[][] {{"book9","4563"},{"book10","9873"},{"book11","6543"}};
	}
	
	
}