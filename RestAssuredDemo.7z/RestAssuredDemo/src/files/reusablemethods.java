package files;

import io.restassured.path.xml.XmlPath;
import io.restassured.response.Response;

public  class reusablemethods {

	public static XmlPath rawToXml(Response res) {
	
	String responseString =res.asString();
	XmlPath xm = new XmlPath(responseString);
	return xm;
	}
	
	/*public static JsonPath rawToJson(Response res) {
		
		String responseString =res.asString();
		JsonPath js = new JsonPath(responseString);
		return js;
		}
	*/
}
