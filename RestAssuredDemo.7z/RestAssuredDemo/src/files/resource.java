package files;

public class resource {

	
	public String getpostdata() {
		
		String resource="/maps/api/place/add/json";
		return resource;
	}

}
