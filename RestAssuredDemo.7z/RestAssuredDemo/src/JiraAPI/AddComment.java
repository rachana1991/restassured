package JiraAPI;

import static io.restassured.RestAssured.given;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class AddComment {
	@Test
	public void addComment() {
		RestAssured.baseURI="http://localhost:8080";
		Response res=given().header("Content-Type","application/json").
		header("Cookie","JSESSIONID="+ReusableMethods.getSessionID()).
		body("{\r\n" + 
				"    \"body\": \"This is comment from automated rest api \",\r\n" + 
				"    \"visibility\": {\r\n" + 
				"        \"type\": \"role\",\r\n" + 
				"        \"value\": \"Administrators\"\r\n" + 
				"    }\r\n" + 
				"}\r\n" + 
				"").
		when().
		post("/rest/api/2/issue/10005/comment").
		then().statusCode(201).extract().response();
		String responseString =res.asString();
		JsonPath js=new JsonPath(responseString);
		String bugID= js.get("id");
		System.out.println(bugID);
	}
}
