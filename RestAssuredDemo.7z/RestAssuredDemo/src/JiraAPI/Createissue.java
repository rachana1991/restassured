package JiraAPI;

import org.testng.annotations.Test;
import static io.restassured.RestAssured.given;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class Createissue {

	
	@Test
	public static void createIssue() {
		
		RestAssured.baseURI="http://localhost:8080";
		Response res= given().header("Content-Type","application/json").
		header("Cookie","JSESSIONID="+ReusableMethods.getSessionID()).
		body("{\r\n" + 
				"    \"fields\": {\r\n" + 
				"       \"project\":\r\n" + 
				"       {\r\n" + 
				"          \"key\": \"JIR\"\r\n" + 
				"       },\r\n" + 
				"       \"summary\": \"automate issue\",\r\n" + 
				"       \"description\": \"this is my first automated issue\",\r\n" + 
				"       \"issuetype\": {\r\n" + 
				"          \"name\": \"Bug\"\r\n" + 
				"       }\r\n" + 
				"   }\r\n" + 
				" }").
		when().
		post("/rest/api/2/issue").then().
		statusCode(201).extract().response();
		
		String responseString =res.asString();
		JsonPath js=new JsonPath(responseString);
		String bugID= js.get("id");
		System.out.println(bugID);
	}
}
