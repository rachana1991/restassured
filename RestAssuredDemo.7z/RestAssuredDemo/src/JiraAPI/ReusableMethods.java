package JiraAPI;

import static io.restassured.RestAssured.given;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class ReusableMethods {

	
	public static String getSessionID() {
		
		RestAssured.baseURI="http://localhost:8080";
		Response res=given().header("Content-Type","application/json").body("{ \"username\": \"rachana19\", \"password\": \"Test@1234\" }").
		when().
		post("/rest/auth/1/session").
		then().
		statusCode(200).extract().response();
		
		String responseString =res.asString();
		JsonPath js = new JsonPath(responseString);
		String sessionId= js.get("session.value");
		System.out.println(sessionId);
		return sessionId;
	}
}
