package GoogleAPI;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Properties;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import files.payload;
import files.resource;
import files.reusablemethods;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.path.xml.XmlPath;
import io.restassured.response.Response;

public class AddDeleteXML {
	// Add and Delete a place
	//To delete a place first we need to grab the response of the post request and 
	//then extract the place ID from the response. Use this place ID as an input to the Delete request.

	Properties prop= new Properties();
	resource r=new resource();
	
	@BeforeTest
	public void setup() throws IOException {
		FileInputStream fis = new FileInputStream("C:\\Users\\racmhatr\\eclipse-workspace\\RestAssuredDemo\\src\\files\\prop.properties");
		prop.load(fis);
	}
	
	
	@Test
	public void addDeletePlace() throws IOException {
		
		String xmlbody= GenerateStringFromResource("C:\\Users\\racmhatr\\eclipse-workspace\\RestAssuredDemo\\src\\files\\postdata.xml");
		
		RestAssured.baseURI=prop.getProperty("host");
		//extract response in res variable
		Response res = given().
		queryParam("key",prop.getProperty("key")).		
		body(xmlbody).log().all().
		when().
		post("/maps/api/place/add/xml").
		then().assertThat().statusCode(200).and().contentType(ContentType.XML).log().all().
		extract().response();	
		
	  XmlPath xm= reusablemethods.rawToXml(res);
		String placeId= xm.get("PlaceAddResponse.place_id");
		System.out.println(placeId);
		
	
		
		//delete the added place
		given().
		queryParam("key","qaclick123").		
		body("{"+
			" \"place_id\": \""+placeId+"\""+
		"}").
		when().
		post("/maps/api/place/delete/json").
		then().assertThat().statusCode(200).and().contentType(ContentType.JSON);
		
		}
	
	public static String GenerateStringFromResource(String path) throws IOException{
		return new String(Files.readAllBytes(Paths.get(path)));
		}

	
}
