package GoogleAPI;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import static org.hamcrest.Matchers.equalTo;

import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;

public class getAndPost {
//GET and POST request automation - Google place API- Get place and add new place
	@Test
	public void getrequest() {

		// public static void main (String[]args){
		RestAssured.baseURI = "https://maps.googleapis.com";
		
		given().
		param("location", "-33.8670522,151.1957362").
				param("key", "AIzaSyAKnF0DhFq29IRzKwJ1Hi6rhYBdAIdQ4dw").
				param("radius", "500").
				when().
				get("/maps/api/place/nearbysearch/json").
				
				then().assertThat().statusCode(200).and().
				contentType(ContentType.JSON).and().
				body("results[0].name", equalTo("Sydney")).and().
				body("results[0].place_id", equalTo("ChIJP3Sa8ziYEmsRUKgyFmh9AQM")).and().
				header("Server", "scaffolding on HTTPServer2");
	}

	
	
	@Test
	public void postrequest() {
		RestAssured.baseURI="http://216.10.245.166";
		given().
		queryParam("key","qaclick123").		
		body("{\r\n" + 
				"\r\n" + 
				"    \"location\":{\r\n" + 
				"\r\n" + 
				"        \"lat\" : -38.383494,\r\n" + 
				"\r\n" + 
				"        \"lng\" : 33.427362\r\n" + 
				"\r\n" + 
				"    },\r\n" + 
				"\r\n" + 
				"    \"accuracy\":50,\r\n" + 
				"\r\n" + 
				"    \"name\":\"Frontline house\",\r\n" + 
				"\r\n" + 
				"    \"phone_number\":\"(+91) 983 893 3937\",\r\n" + 
				"\r\n" + 
				"    \"address\" : \"29, side layout, cohen 09\",\r\n" + 
				"\r\n" + 
				"    \"types\": [\"shoe park\",\"shop\"],\r\n" + 
				"\r\n" + 
				"    \"website\" : \"http://google.com\",\r\n" + 
				"\r\n" + 
				"    \"language\" : \"French-IN\"\r\n" + 
				"\r\n" + 
				"}\r\n" + 
				"").
		when().
		post("/maps/api/place/add/json").
		then().assertThat().statusCode(200).and().contentType(ContentType.JSON).and().
		body("status",equalTo("OK"));	
	}
	
	

}
