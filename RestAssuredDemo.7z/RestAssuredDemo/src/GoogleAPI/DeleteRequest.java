package GoogleAPI;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import files.payload;
import files.resource;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class DeleteRequest {
	// Add and Delete a place
	//To delete a place first we need to grab the response of the post request and 
	//then extract the place ID from the response. Use this place ID as an input to the Delete request.

	Properties prop= new Properties();
	resource r=new resource();
	
	@BeforeTest
	public void setup() throws IOException {
		FileInputStream fis = new FileInputStream("C:\\Users\\racmhatr\\eclipse-workspace\\RestAssuredDemo\\src\\files\\prop.properties");
		prop.load(fis);
		
	}
	
	
	@Test
	public void addDeletePlace() {
		
		RestAssured.baseURI=prop.getProperty("host");
		//extract response in res variable
		Response res= given().
		queryParam("key",prop.getProperty("key")).		
		body(payload.getpayload()).
		when().
		post(r.getpostdata()).
		then().assertThat().statusCode(200).and().contentType(ContentType.JSON).and().
		body("status",equalTo("OK")).
		extract().response();	
		
		//Convert res which is in raw format into string
		String responseString =res.asString();
		System.out.println(responseString);
		
		//convert string to json to use methods for pulling the placeid
		JsonPath js = new JsonPath(responseString);
		String placeId= js.get("place_id");
		System.out.println(placeId);
		//place Id is grabbed from the response
	
		
		//delete the added place
		given().
		queryParam("key","qaclick123").		
		body("{"+
			" \"place_id\": \""+placeId+"\""+
		"}").
		when().
		post("/maps/api/place/delete/json").
		then().assertThat().statusCode(200).and().contentType(ContentType.JSON).and().
		body("status",equalTo("OK"));
		
	}
}
